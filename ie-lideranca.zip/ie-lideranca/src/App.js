import { useState } from "react";

const initialMessages = [
  { id: 1, category: "autoconhecimento", title: "Reconheça suas emoções", content: "Antes de reagir, respire. Identificar o que você sente é o primeiro passo para uma resposta emocionalmente inteligente. Pergunte-se: 'O que estou sentindo agora e por quê?'", icon: "🔍", color: "#FF6B6B" },
  { id: 2, category: "empatia", title: "O poder da escuta ativa", content: "Ouvir de verdade é uma habilidade rara. Desligue o piloto automático das respostas e mergulhe genuinamente na perspectiva do outro. Sua presença plena transforma conversas.", icon: "👂", color: "#4ECDC4" },
  { id: 3, category: "resiliencia", title: "Transforme adversidades", content: "Cada obstáculo carrega uma lição. A resiliência não é ausência de dor — é a capacidade de atravessá-la e emergir com mais sabedoria. Você já superou 100% dos seus dias difíceis.", icon: "🌱", color: "#45B7D1" },
  { id: 4, category: "comunicacao", title: "Fale com clareza e compaixão", content: "A comunicação assertiva é uma ponte, não uma arma. Expresse suas necessidades com honestidade e cuidado. 'Eu sinto...' abre portas que 'Você sempre...' fecha.", icon: "💬", color: "#96CEB4" },
  { id: 5, category: "lideranca", title: "Lidere com vulnerabilidade", content: "Os líderes mais inspiradores não fingem ter todas as respostas. Eles criam ambientes seguros onde as pessoas podem ser autênticas, errar e crescer juntas.", icon: "🌟", color: "#FFEAA7" },
  { id: 6, category: "autogestao", title: "Domine seu estado interno", content: "Suas emoções são informações valiosas, não ordens a serem obedecidas. Você pode sentir raiva sem agir por raiva. Esse espaço entre estímulo e resposta é onde mora sua liberdade.", icon: "⚡", color: "#DDA0DD" },
];

const author = {
  name: "Ana Beatriz Mendes",
  title: "Psicóloga & Coach de Desenvolvimento Humano",
  bio: "Com mais de 15 anos dedicados ao desenvolvimento humano, acredito que a inteligência emocional é a habilidade mais transformadora que um ser humano pode cultivar. Especialista em comportamento organizacional pela USP, acompanhei mais de 2.000 pessoas em suas jornadas de autoconhecimento e crescimento profissional.",
  avatar: "👩‍💼",
  stats: [
    { label: "Anos de Experiência", value: "15+" },
    { label: "Pessoas Impactadas", value: "2K+" },
    { label: "Publicações", value: "47" },
  ],
};

const categoryColors = {
  autoconhecimento: "#FF6B6B", empatia: "#4ECDC4", resiliencia: "#45B7D1",
  comunicacao: "#96CEB4", lideranca: "#FFEAA7", autogestao: "#DDA0DD",
};

const categoryLabels = {
  autoconhecimento: "Autoconhecimento", empatia: "Empatia", resiliencia: "Resiliência",
  comunicacao: "Comunicação", lideranca: "Liderança", autogestao: "Autogestão",
};

export default function App() {
  const [screen, setScreen] = useState("home");
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [messages, setMessages] = useState(initialMessages);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMsg, setNewMsg] = useState({ title: "", content: "", category: "autoconhecimento", icon: "💡" });
  const [activeTab, setActiveTab] = useState("todas");
  const iconOptions = ["💡", "🎯", "🧠", "❤️", "🤝", "🔥", "🌈", "⭐", "🏆", "🌺"];

  const handleAddMessage = () => {
    if (!newMsg.title || !newMsg.content) return;
    setMessages([...messages, { id: Date.now(), ...newMsg, color: categoryColors[newMsg.category] }]);
    setNewMsg({ title: "", content: "", category: "autoconhecimento", icon: "💡" });
    setShowAddForm(false);
  };

  const handleDelete = (id) => {
    setMessages(messages.filter((m) => m.id !== id));
    setSelectedMessage(null);
    setScreen("home");
  };

  return (
    <div style={s.root}>
      <div style={s.screen}>
        {screen === "home" && (
          <HomeScreen messages={messages} activeTab={activeTab} setActiveTab={setActiveTab}
            setScreen={setScreen} setSelectedMessage={setSelectedMessage}
            showAddForm={showAddForm} setShowAddForm={setShowAddForm}
            newMsg={newMsg} setNewMsg={setNewMsg} handleAddMessage={handleAddMessage} iconOptions={iconOptions} />
        )}
        {screen === "author" && <AuthorScreen setScreen={setScreen} />}
        {screen === "detail" && selectedMessage && (
          <DetailScreen message={selectedMessage} setScreen={setScreen} handleDelete={handleDelete} />
        )}
      </div>
      <div style={s.tabBar}>
        {[{ id: "home", icon: "🧠", label: "Início" }, { id: "author", icon: "👤", label: "Autor" }].map((tab) => (
          <button key={tab.id} onClick={() => setScreen(tab.id)}
            style={{ ...s.tabButton, color: screen === tab.id ? "#1E3A5F" : "#9CA3AF" }}>
            <span style={s.tabIcon}>{tab.icon}</span>
            <span style={s.tabLabel}>{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function HomeScreen({ messages, activeTab, setActiveTab, setScreen, setSelectedMessage, showAddForm, setShowAddForm, newMsg, setNewMsg, handleAddMessage, iconOptions }) {
  const categories = ["todas", ...Object.keys(categoryLabels)];
  const filtered = activeTab === "todas" ? messages : messages.filter((m) => m.category === activeTab);

  return (
    <div style={s.page}>
      <div style={s.homeHeader}>
        <div>
          <div style={s.appBadge}>
            <span style={{ fontSize: 18 }}>🧠</span>
            <span style={s.appBadgeText}>IE & Liderança</span>
          </div>
          <p style={s.homeSubtitle}>Inteligência Emocional & Soft Skills</p>
        </div>
        <button onClick={() => setShowAddForm(!showAddForm)} style={s.addButton}>
          {showAddForm ? "✕" : "+"}
        </button>
      </div>

      {showAddForm && (
        <div style={s.addForm}>
          <p style={s.formTitle}>Nova Mensagem</p>
          <input style={s.formInput} placeholder="Título" value={newMsg.title}
            onChange={(e) => setNewMsg({ ...newMsg, title: e.target.value })} />
          <textarea style={{ ...s.formInput, height: 80, resize: "none" }}
            placeholder="Conteúdo da mensagem..." value={newMsg.content}
            onChange={(e) => setNewMsg({ ...newMsg, content: e.target.value })} />
          <select style={{ ...s.formInput, marginBottom: 10 }} value={newMsg.category}
            onChange={(e) => setNewMsg({ ...newMsg, category: e.target.value })}>
            {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
          <div style={s.iconPicker}>
            {iconOptions.map((icon) => (
              <button key={icon} onClick={() => setNewMsg({ ...newMsg, icon })}
                style={{ ...s.iconOption, background: newMsg.icon === icon ? "#DBEAFE" : "transparent", borderColor: newMsg.icon === icon ? "#1E3A5F" : "#E5E7EB" }}>
                {icon}
              </button>
            ))}
          </div>
          <button onClick={handleAddMessage} style={s.saveButton}>Salvar Mensagem</button>
        </div>
      )}

      <div style={s.categoryScroll}>
        {categories.map((cat) => (
          <button key={cat} onClick={() => setActiveTab(cat)}
            style={{ ...s.categoryChip, background: activeTab === cat ? "#1E3A5F" : "#F3F4F6", color: activeTab === cat ? "#fff" : "#6B7280" }}>
            {cat === "todas" ? "Todas" : categoryLabels[cat]}
          </button>
        ))}
      </div>

      <div style={s.messageGrid}>
        {filtered.map((msg) => (
          <button key={msg.id} style={s.messageCard} onClick={() => { setSelectedMessage(msg); setScreen("detail"); }}>
            <div style={{ ...s.cardIconBg, background: msg.color + "22" }}>
              <span style={s.cardIcon}>{msg.icon}</span>
            </div>
            <p style={s.cardTitle}>{msg.title}</p>
            <span style={{ ...s.cardBadge, background: msg.color + "22", color: msg.color }}>
              {categoryLabels[msg.category]}
            </span>
          </button>
        ))}
      </div>

      <p style={s.footerNote}>Inteligência Emocional &amp; Liderança</p>
    </div>
  );
}

function DetailScreen({ message, setScreen, handleDelete }) {
  return (
    <div style={s.page}>
      <div style={s.detailHeader}>
        <button onClick={() => setScreen("home")} style={s.backButton}>← Voltar</button>
        <button onClick={() => handleDelete(message.id)} style={s.deleteButton}>🗑</button>
      </div>
      <div style={s.detailHero}>
        <div style={{ ...s.detailIconBg, background: message.color + "22" }}>
          <span style={s.detailIcon}>{message.icon}</span>
        </div>
        <span style={{ ...s.detailBadge, background: message.color + "22", color: message.color }}>
          {categoryLabels[message.category]}
        </span>
      </div>
      <h1 style={s.detailTitle}>{message.title}</h1>
      <div style={s.detailCard}>
        <div style={{ width: 4, background: message.color, borderRadius: 4, marginRight: 16, flexShrink: 0 }} />
        <p style={s.detailContent}>{message.content}</p>
      </div>
      <div style={s.reflectBox}>
        <p style={s.reflectTitle}>💭 Reflita sobre isso</p>
        <p style={s.reflectText}>Como você pode aplicar essa ideia no seu dia a dia? Tome um momento para internalizar essa mensagem.</p>
      </div>
    </div>
  );
}

function AuthorScreen({ setScreen }) {
  return (
    <div style={s.page}>
      <div style={s.authorHero}>
        <div style={s.authorAvatarBg}>
          <span style={s.authorAvatar}>{author.avatar}</span>
        </div>
      </div>
      <div style={s.authorInfo}>
        <h1 style={s.authorName}>{author.name}</h1>
        <p style={s.authorTitle}>{author.title}</p>
      </div>
      <div style={s.statsRow}>
        {author.stats.map((st) => (
          <div key={st.label} style={s.statBox}>
            <p style={s.statValue}>{st.value}</p>
            <p style={s.statLabel}>{st.label}</p>
          </div>
        ))}
      </div>
      <div style={s.bioCard}>
        <p style={s.bioTitle}>Sobre</p>
        <p style={s.bioText}>{author.bio}</p>
      </div>
      <div style={s.missionCard}>
        <span style={{ fontSize: 28, marginBottom: 8, display: "block" }}>✨</span>
        <p style={s.missionTitle}>Missão</p>
        <p style={s.missionText}>"Acredito que quando desenvolvemos nossa inteligência emocional, transformamos não só nossa vida profissional, mas todos os relacionamentos que cultivamos."</p>
      </div>
    </div>
  );
}

const s = {
  root: {
    display: "flex", flexDirection: "column", height: "100dvh",
    fontFamily: "'SF Pro Display', -apple-system, BlinkMacSystemFont, sans-serif",
    background: "#F0F4F8", maxWidth: 430, margin: "0 auto", position: "relative",
  },
  screen: { flex: 1, overflowY: "auto", WebkitOverflowScrolling: "touch" },
  tabBar: {
    height: 80, background: "rgba(255,255,255,0.97)", backdropFilter: "blur(20px)",
    borderTop: "1px solid #E5E7EB", display: "flex", justifyContent: "space-around",
    alignItems: "flex-start", paddingTop: 10, flexShrink: 0,
    paddingBottom: "env(safe-area-inset-bottom)",
  },
  tabButton: { display: "flex", flexDirection: "column", alignItems: "center", background: "none", border: "none", cursor: "pointer", gap: 3, padding: "0 32px" },
  tabIcon: { fontSize: 26 },
  tabLabel: { fontSize: 11, fontWeight: 600 },
  page: { padding: "20px 20px 32px" },
  homeHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20 },
  appBadge: { display: "inline-flex", alignItems: "center", gap: 8, background: "linear-gradient(135deg, #1E3A5F, #2E6DA4)", borderRadius: 20, padding: "6px 14px", marginBottom: 6 },
  appBadgeText: { color: "#fff", fontWeight: 800, fontSize: 16, letterSpacing: -0.5 },
  homeSubtitle: { color: "#6B7280", fontSize: 13, margin: 0 },
  addButton: { width: 44, height: 44, borderRadius: 22, background: "linear-gradient(135deg, #1E3A5F, #2E6DA4)", border: "none", color: "#fff", fontSize: 26, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 12px rgba(30,58,95,0.4)", flexShrink: 0 },
  addForm: { background: "#fff", borderRadius: 20, padding: 16, marginBottom: 16, boxShadow: "0 4px 20px rgba(0,0,0,0.08)" },
  formTitle: { fontWeight: 700, fontSize: 16, color: "#111", margin: "0 0 12px" },
  formInput: { width: "100%", padding: "10px 14px", borderRadius: 12, border: "1.5px solid #E5E7EB", fontSize: 15, marginBottom: 10, outline: "none", boxSizing: "border-box", fontFamily: "inherit", background: "#FAFAFA" },
  iconPicker: { display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 12 },
  iconOption: { width: 44, height: 44, borderRadius: 12, border: "1.5px solid", cursor: "pointer", fontSize: 22, display: "flex", alignItems: "center", justifyContent: "center" },
  saveButton: { width: "100%", padding: "13px", borderRadius: 14, background: "linear-gradient(135deg, #1E3A5F, #2E6DA4)", border: "none", color: "#fff", fontWeight: 700, fontSize: 16, cursor: "pointer", boxShadow: "0 4px 12px rgba(30,58,95,0.35)" },
  categoryScroll: { display: "flex", gap: 8, overflowX: "auto", marginBottom: 20, paddingBottom: 4, scrollbarWidth: "none" },
  categoryChip: { padding: "8px 16px", borderRadius: 20, border: "none", fontSize: 13, fontWeight: 600, cursor: "pointer", whiteSpace: "nowrap" },
  messageGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 },
  messageCard: { background: "#fff", borderRadius: 20, padding: 16, border: "none", cursor: "pointer", textAlign: "left", boxShadow: "0 2px 12px rgba(0,0,0,0.06)", display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 10 },
  cardIconBg: { width: 56, height: 56, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center" },
  cardIcon: { fontSize: 30 },
  cardTitle: { fontSize: 13, fontWeight: 700, color: "#111", margin: 0, lineHeight: 1.3 },
  cardBadge: { fontSize: 10, fontWeight: 700, padding: "3px 10px", borderRadius: 20, textTransform: "uppercase", letterSpacing: 0.5 },
  detailHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 },
  backButton: { background: "#fff", border: "none", color: "#1E3A5F", fontWeight: 700, fontSize: 16, cursor: "pointer", padding: "8px 16px", borderRadius: 20, boxShadow: "0 2px 8px rgba(0,0,0,0.08)" },
  deleteButton: { background: "#FEE2E2", border: "none", fontSize: 18, cursor: "pointer", padding: "8px 12px", borderRadius: 16 },
  detailHero: { display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 24 },
  detailIconBg: { width: 100, height: 100, borderRadius: 32, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12 },
  detailIcon: { fontSize: 52 },
  detailBadge: { fontSize: 12, fontWeight: 700, padding: "5px 16px", borderRadius: 20, textTransform: "uppercase", letterSpacing: 0.5 },
  detailTitle: { fontSize: 24, fontWeight: 800, color: "#111", textAlign: "center", margin: "0 0 20px", lineHeight: 1.25 },
  detailCard: { background: "#fff", borderRadius: 20, padding: 20, marginBottom: 16, display: "flex", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" },
  detailContent: { fontSize: 16, lineHeight: 1.7, color: "#374151", margin: 0 },
  reflectBox: { background: "linear-gradient(135deg, #DBEAFE, #EFF6FF)", borderRadius: 20, padding: 20 },
  reflectTitle: { fontWeight: 700, fontSize: 15, color: "#1E3A5F", margin: "0 0 8px" },
  reflectText: { fontSize: 14, color: "#6B7280", lineHeight: 1.6, margin: 0 },
  authorHero: { display: "flex", justifyContent: "center", marginBottom: 20 },
  authorAvatarBg: { width: 100, height: 100, borderRadius: 50, background: "linear-gradient(135deg, #DBEAFE, #EFF6FF)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 8px 24px rgba(30,58,95,0.2)", border: "3px solid #fff" },
  authorAvatar: { fontSize: 52 },
  authorInfo: { textAlign: "center", marginBottom: 24 },
  authorName: { fontSize: 24, fontWeight: 800, color: "#111", margin: "0 0 6px" },
  authorTitle: { color: "#1E3A5F", fontWeight: 600, fontSize: 14, margin: 0 },
  statsRow: { display: "flex", gap: 12, marginBottom: 20 },
  statBox: { flex: 1, background: "#fff", borderRadius: 16, padding: "14px 10px", textAlign: "center", boxShadow: "0 2px 12px rgba(0,0,0,0.06)" },
  statValue: { fontSize: 22, fontWeight: 800, color: "#1E3A5F", margin: "0 0 4px" },
  statLabel: { fontSize: 10, color: "#9CA3AF", fontWeight: 600, margin: 0 },
  bioCard: { background: "#fff", borderRadius: 20, padding: 20, marginBottom: 16, boxShadow: "0 2px 12px rgba(0,0,0,0.06)" },
  bioTitle: { fontWeight: 700, fontSize: 16, color: "#111", margin: "0 0 10px" },
  bioText: { fontSize: 14, color: "#6B7280", lineHeight: 1.7, margin: 0 },
  missionCard: { background: "linear-gradient(135deg, #1E3A5F, #2E6DA4)", borderRadius: 20, padding: 20, textAlign: "center" },
  missionTitle: { fontWeight: 700, fontSize: 15, color: "rgba(255,255,255,0.8)", margin: "0 0 8px", textTransform: "uppercase", letterSpacing: 1 },
  missionText: { fontSize: 14, color: "#fff", lineHeight: 1.7, margin: 0, fontStyle: "italic" },
  footerNote: { textAlign: "center", fontSize: 10, color: "#B0B8C4", marginTop: 24, marginBottom: 0, letterSpacing: 0.3, fontStyle: "italic" },
};
